-- AlterTable
ALTER TABLE "multi"."legal_representatives" ADD COLUMN     "documentUrl" VARCHAR(1000),
ADD COLUMN     "position" VARCHAR(100);
